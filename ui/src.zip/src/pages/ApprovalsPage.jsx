import { useEffect, useMemo, useState } from "react";
import {
  Box,
  Button,
  Chip,
  Divider,
  IconButton,
  Paper,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import {
  CheckCircleOutlined,
  CloseOutlined,
  EditOutlined,
  FactCheckOutlined,
  MoreHorizOutlined,
  ReplayOutlined,
  RefreshOutlined,
  ScheduleOutlined,
  VisibilityOutlined,
} from "@mui/icons-material";
import { api } from "../api/client";

function getStatusMeta(status) {
  const value = String(status || "pending_approval").toLowerCase();

  if (value.includes("approved")) {
    return { label: "Approved", color: "#16a34a", bg: "rgba(22,163,74,0.12)" };
  }
  if (value.includes("rejected")) {
    return { label: "Rejected", color: "#ef4444", bg: "rgba(239,68,68,0.12)" };
  }
  if (value.includes("pending") || value.includes("review")) {
    return { label: "Pending", color: "#d97706", bg: "rgba(217,119,6,0.12)" };
  }
  return { label: "Review", color: "#64748b", bg: "rgba(148,163,184,0.12)" };
}

function normalizeItem(raw) {
  return {
    id: raw.id,
    run_id: raw.run_id,
    module_title: raw.module_title || "Untitled module",
    question: raw.question || "",
    answer_key: raw.answer_key || "",
    document_title: raw.document_title || "Unknown document",
    page_number: raw.page_number ?? "—",
    standard: raw.standard || "N/A",
    status: raw.status || "pending_approval",
    review_comment: raw.review_comment || "",
    reviewed_by: raw.reviewed_by || "",
  };
}

export default function ApprovalsPage() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selectedId, setSelectedId] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [reviewComment, setReviewComment] = useState("");
  const [editedQuestion, setEditedQuestion] = useState("");
  const [editedAnswerKey, setEditedAnswerKey] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function loadItems() {
    try {
      setLoading(true);
      setError("");
      const data = await api("/workflow/items/pending");
      const normalized = (Array.isArray(data) ? data : []).map(normalizeItem);
      setItems(normalized);
      if (!selectedId && normalized.length > 0) {
        setSelectedId(normalized[0].id);
      }
      if (normalized.length === 0) {
        setSelectedId("");
      }
    } catch (err) {
      setError(err.message || "Unable to load pending approvals");
      setItems([]);
      setSelectedId("");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadItems();
  }, []);

  const selectedItem = useMemo(
    () => items.find((item) => item.id === selectedId) || items[0] || null,
    [items, selectedId]
  );

  useEffect(() => {
    if (!selectedItem) {
      setEditedQuestion("");
      setEditedAnswerKey("");
      setReviewComment("");
      return;
    }

    setEditedQuestion(selectedItem.question || "");
    setEditedAnswerKey(selectedItem.answer_key || "");
    setReviewComment(selectedItem.review_comment || "");
    setIsEditing(false);
  }, [selectedItem]);

  async function handleReview(decision) {
    if (!selectedItem) return;

    const payload = {
      decision,
      comment: reviewComment.trim() || undefined,
      edited_question:
        decision === "edit_and_approve" ? editedQuestion.trim() || undefined : undefined,
      edited_answer_key:
        decision === "edit_and_approve" ? editedAnswerKey.trim() || undefined : undefined,
    };

    try {
      setSubmitting(true);
      setError("");
      await api(`/workflow/items/${selectedItem.id}/review`, {
        method: "POST",
        body: payload,
      });
      await loadItems();
      setIsEditing(false);
    } catch (err) {
      setError(err.message || "Unable to submit review");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Box sx={{ minHeight: "100%", background: "#f3f6fb", borderRadius: 3, overflow: "hidden" }}>
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          px: 2.5,
          py: 1.8,
          borderBottom: "1px solid rgba(15, 23, 42, 0.08)",
          background: "rgba(255,255,255,0.75)",
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <Typography variant="h5" sx={{ fontWeight: 800, color: "#0f172a" }}>
            Approvals
          </Typography>
          <Chip
            label="Lead Instructor Portal"
            size="small"
            sx={{ background: "#e2e8f0", color: "#0f172a", fontWeight: 700 }}
          />
        </Box>

        <Stack direction="row" spacing={1}>
          <Button
            variant="contained"
            startIcon={<RefreshOutlined />}
            onClick={loadItems}
            sx={{ bgcolor: "#0f172a", borderRadius: 2, textTransform: "none" }}
          >
            Refresh
          </Button>
          <Button
            variant="outlined"
            startIcon={<ReplayOutlined />}
            sx={{ color: "#0f172a", borderColor: "rgba(15,23,42,0.15)", borderRadius: 2, textTransform: "none" }}
          >
            Re-run validation
          </Button>
        </Stack>
      </Box>

      <Box sx={{ p: 2.5 }}>
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: { xs: "1fr", lg: "340px minmax(0, 1fr)" },
            gap: 3,
          }}
        >
          <Paper
            elevation={0}
            sx={{
              borderRadius: 3,
              border: "1px solid rgba(148,163,184,0.2)",
              background: "#ffffff",
              p: 2,
            }}
          >
            <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 2 }}>
              <Typography sx={{ fontSize: 18, fontWeight: 800, color: "#0f172a" }}>
                Review Queue
              </Typography>
              <Chip
                label={items.length}
                size="small"
                sx={{ background: "#dbeafe", color: "#1d4ed8", fontWeight: 800 }}
              />
            </Box>

            <Stack spacing={1.2}>
              {loading ? (
                <Typography sx={{ color: "#475569", p: 2 }}>Loading approvals…</Typography>
              ) : items.length === 0 ? (
                <Box sx={{ p: 2, borderRadius: 2, background: "#f8fafc", border: "1px dashed #cbd5e1" }}>
                  <Typography sx={{ color: "#475569" }}>No items are waiting for approval.</Typography>
                </Box>
              ) : (
                items.map((item) => {
                  const meta = getStatusMeta(item.status);
                  return (
                    <Box
                      key={item.id}
                      onClick={() => setSelectedId(item.id)}
                      sx={{
                        border: selectedItem?.id === item.id ? "1px solid #2563eb" : "1px solid rgba(148,163,184,0.2)",
                        borderRadius: 2,
                        background: selectedItem?.id === item.id ? "#eff6ff" : "#f8fafc",
                        p: 1.4,
                        cursor: "pointer",
                        transition: "all 0.2s ease",
                        boxShadow: selectedItem?.id === item.id ? "0 8px 18px rgba(37,99,235,0.08)" : "none",
                      }}
                    >
                      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 0.7 }}>
                        <Typography sx={{ fontWeight: 800, color: "#0f172a" }}>{item.module_title}</Typography>
                        <Chip
                          label={meta.label}
                          size="small"
                          sx={{ background: meta.bg, color: meta.color, fontWeight: 700 }}
                        />
                      </Box>

                      <Typography sx={{ color: "#475569", fontSize: 14, mb: 0.8 }}>
                        {item.document_title} • page {item.page_number}
                      </Typography>

                      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                        <Typography sx={{ color: "#334155", fontSize: 12, fontWeight: 700 }}>
                          {item.run_id}
                        </Typography>
                        <Typography sx={{ color: "#64748b", fontSize: 12 }}>
                          {item.standard}
                        </Typography>
                      </Box>
                    </Box>
                  );
                })
              )}
            </Stack>
          </Paper>

          <Paper elevation={0} sx={{ borderRadius: 3, border: "1px solid rgba(148,163,184,0.2)", background: "#ffffff", overflow: "hidden" }}>
            {selectedItem ? (
              <>
                <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", p: 2.5, borderBottom: "1px solid rgba(148,163,184,0.12)" }}>
                  <Box>
                    <Typography sx={{ fontSize: 14, color: "#64748b", fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.8 }}>
                      Item #{selectedItem.id.slice(0, 8)}
                    </Typography>
                    <Typography sx={{ fontWeight: 800, color: "#0f172a", fontSize: 20 }}>
                      {selectedItem.module_title}
                    </Typography>
                  </Box>

                  <Stack direction="row" spacing={1}>
                    <Chip
                      icon={<FactCheckOutlined sx={{ fontSize: 16 }} />}
                      label="Validation passed"
                      size="small"
                      sx={{ background: "rgba(52,211,153,0.12)", color: "#15803d", fontWeight: 700 }}
                    />
                    <IconButton size="small" sx={{ border: "1px solid rgba(148,163,184,0.2)" }}>
                      <MoreHorizOutlined fontSize="small" />
                    </IconButton>
                  </Stack>
                </Box>

                <Box sx={{ p: 2.5 }}>
                  <Box sx={{ display: "grid", gap: 2, gridTemplateColumns: { xs: "1fr", md: "1.2fr 0.8fr" }, alignItems: "start" }}>
                    <Box sx={{ border: "1px solid rgba(148,163,184,0.18)", borderRadius: 2, background: "#f8fafc", p: 2 }}>
                      <Typography sx={{ fontWeight: 800, color: "#0f172a", mb: 1 }}>Question Text</Typography>
                      {isEditing ? (
                        <TextField
                          fullWidth
                          multiline
                          minRows={4}
                          value={editedQuestion}
                          onChange={(event) => setEditedQuestion(event.target.value)}
                          sx={{ background: "#fff" }}
                        />
                      ) : (
                        <Typography sx={{ color: "#0f172a", lineHeight: 1.8 }}>{selectedItem.question}</Typography>
                      )}
                    </Box>

                    <Box sx={{ border: "1px solid rgba(148,163,184,0.18)", borderRadius: 2, background: "#f8fafc", p: 2 }}>
                      <Typography sx={{ fontWeight: 800, color: "#0f172a", mb: 1 }}>Answer Key</Typography>
                      {isEditing ? (
                        <TextField
                          fullWidth
                          multiline
                          minRows={4}
                          value={editedAnswerKey}
                          onChange={(event) => setEditedAnswerKey(event.target.value)}
                          sx={{ background: "#fff" }}
                        />
                      ) : (
                        <Typography sx={{ color: "#0f172a", lineHeight: 1.8 }}>{selectedItem.answer_key}</Typography>
                      )}
                    </Box>
                  </Box>

                  <Box sx={{ mt: 2, border: "1px solid rgba(148,163,184,0.18)", background: "#f8fafc", borderRadius: 2, p: 2 }}>
                    <Typography sx={{ fontWeight: 800, color: "#0f172a", mb: 1 }}>Review notes</Typography>
                    <TextField
                      fullWidth
                      multiline
                      minRows={3}
                      placeholder="Add a note for the reviewer or for the final approval record"
                      value={reviewComment}
                      onChange={(event) => setReviewComment(event.target.value)}
                    />
                  </Box>

                  <Box sx={{ mt: 2.5, display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 1.5 }}>
                    <Stack direction="row" spacing={1}>
                      <Button
                        variant="contained"
                        startIcon={<CheckCircleOutlined />}
                        onClick={() => handleReview("approve")}
                        disabled={submitting}
                        sx={{ bgcolor: "#16a34a", textTransform: "none", borderRadius: 2 }}
                      >
                        Approve
                      </Button>

                      <Button
                        variant="outlined"
                        startIcon={<CloseOutlined />}
                        onClick={() => handleReview("reject")}
                        disabled={submitting}
                        sx={{ borderColor: "rgba(239,68,68,0.3)", color: "#b91c1c", textTransform: "none", borderRadius: 2 }}
                      >
                        Reject
                      </Button>

                      <Button
                        variant="outlined"
                        startIcon={<EditOutlined />}
                        onClick={() => setIsEditing((current) => !current)}
                        sx={{ borderColor: "rgba(15,23,42,0.15)", color: "#0f172a", textTransform: "none", borderRadius: 2 }}
                      >
                        {isEditing ? "Cancel edit" : "Edit"}
                      </Button>
                    </Stack>

                    {isEditing && (
                      <Button
                        variant="contained"
                        startIcon={<CheckCircleOutlined />}
                        onClick={() => handleReview("edit_and_approve")}
                        disabled={submitting}
                        sx={{ bgcolor: "#2563eb", textTransform: "none", borderRadius: 2 }}
                      >
                        Save edit & approve
                      </Button>
                    )}
                  </Box>

                  {error ? (
                    <Box sx={{ mt: 2, borderRadius: 2, background: "#fef2f2", border: "1px solid #fecaca", p: 1.2 }}>
                      <Typography sx={{ color: "#b91c1c" }}>{error}</Typography>
                    </Box>
                  ) : null}
                </Box>
              </>
            ) : (
              <Box sx={{ p: 3 }}>
                <Typography sx={{ color: "#475569" }}>No item selected.</Typography>
              </Box>
            )}
          </Paper>
        </Box>
      </Box>
    </Box>
  );
}
