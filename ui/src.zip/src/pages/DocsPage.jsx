import { useEffect, useMemo, useRef, useState } from "react";
import {
  Box,
  Card,
  Chip,
  Divider,
  LinearProgress,
  List,
  ListItem,
  ListItemButton,
  ListItemText,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
import {
  Add,
  ArticleOutlined,
  CloudUploadOutlined,
  DescriptionOutlined,
  DownloadOutlined,
  FilterAltOutlined,
  FolderOutlined,
  InsertDriveFileOutlined,
  OpenInNewOutlined,
  PictureAsPdfOutlined,
  SearchOutlined,
  ShieldOutlined,
  TableChartOutlined,
  TextSnippetOutlined,
} from "@mui/icons-material";
import Button from "../components/Button";
import { api } from "../api/client";

const API_BASE_URL = import.meta.env.VITE_API_URL ?? "http://localhost:8000";

function normalizeStatus(status) {
  const lower = String(status || "pending").toLowerCase();

  if (lower.includes("failed")) return "Failed";
  if (lower.includes("no_extractable")) return "No text extracted";
  if (lower.includes("processed") || lower.includes("process")) return "Processed";
  if (lower.includes("upload") || lower.includes("queued") || lower.includes("pending")) return "Processing...";

  return "Processing...";
}

function getFileTypeMeta(fileName = "") {
  const extension = String(fileName.split(".").pop() || "").toLowerCase();

  const map = {
    pdf: { label: "PDF", Icon: PictureAsPdfOutlined, color: "#d93025" },
    doc: { label: "DOC", Icon: DescriptionOutlined, color: "#1a73e8" },
    docx: { label: "DOCX", Icon: DescriptionOutlined, color: "#1a73e8" },
    ppt: { label: "PPT", Icon: TableChartOutlined, color: "#f59e0b" },
    pptx: { label: "PPTX", Icon: TableChartOutlined, color: "#f59e0b" },
    xls: { label: "XLS", Icon: TableChartOutlined, color: "#10b981" },
    xlsx: { label: "XLSX", Icon: TableChartOutlined, color: "#10b981" },
    csv: { label: "CSV", Icon: TextSnippetOutlined, color: "#06b6d4" },
    txt: { label: "TXT", Icon: TextSnippetOutlined, color: "#64748b" },
    md: { label: "MD", Icon: TextSnippetOutlined, color: "#8b5cf6" },
  };

  const meta = map[extension] || { label: extension ? extension.toUpperCase() : "FILE", Icon: InsertDriveFileOutlined, color: "#64748b" };

  return meta;
}

function normalizeDocument(raw) {
  const title = raw.title || raw.filename || "Untitled document";
  return {
    id: raw.id || raw.document_id || title || Math.random().toString(36).slice(2),
    title,
    fileName: title,
    specialization: raw.specialization || "General",
    status: normalizeStatus(raw.status),
  };
}

function DocStatusChip({ status }) {
  const palette = {
    Processed: { color: "success.main", bg: "rgba(6, 118, 71, 0.12)" },
    "Processing...": { color: "warning.main", bg: "rgba(245, 158, 11, 0.12)" },
    Failed: { color: "error.main", bg: "rgba(239, 68, 68, 0.12)" },
    "No text extracted": { color: "text.secondary", bg: "rgba(148, 163, 184, 0.14)" },
  };

  const tone = palette[status] || { color: "text.secondary", bg: "rgba(30,41,59,0.08)" };

  return (
    <Chip
      label={status}
      size="small"
      sx={{
        fontWeight: 600,
        backgroundColor: tone.bg,
        color: tone.color,
        borderRadius: 999,
      }}
    />
  );
}

export default function DocsPage() {
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef(null);

  async function loadDocuments() {
    try {
      setLoading(true);
      setError("");
      const data = await api("/tenantdocs");
      const items = Array.isArray(data) ? data : [];
      setDocuments(items.map(normalizeDocument));
    } catch (err) {
      setError(err.message || "Unable to load documents");
      setDocuments([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadDocuments();
  }, []);

  useEffect(() => {
    const hasActiveProcessing = documents.some((doc) => {
      const status = String(doc.status || "").toLowerCase();
      return status.includes("processing") || status.includes("upload") || status.includes("pending") || status.includes("queued");
    });

    if (!hasActiveProcessing) return undefined;

    const timer = setInterval(() => {
      loadDocuments();
    }, 4000);

    return () => clearInterval(timer);
  }, [documents]);

  function buildDocumentUrl(doc) {
    return `${API_BASE_URL}/uploads/${doc.id}_${encodeURIComponent(doc.fileName || doc.title)}`;
  }

  function openDocument(doc) {
    const url = buildDocumentUrl(doc);
    window.open(url, "_blank", "noopener,noreferrer");
  }

  function downloadDocument(doc) {
    const url = buildDocumentUrl(doc);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = doc.fileName || doc.title;
    anchor.target = "_blank";
    anchor.rel = "noopener noreferrer";
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
  }

  async function uploadFile(file) {
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);

    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      const token = localStorage.getItem("access_token");
      xhr.open("POST", `${API_BASE_URL}/upload`);
      if (token) xhr.setRequestHeader("Authorization", `Bearer ${token}`);

      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable) {
          setUploadProgress(Math.round((event.loaded / event.total) * 100));
        }
      };

      xhr.onload = async () => {
        try {
          if (xhr.status >= 400) {
            const parsed = xhr.responseText ? JSON.parse(xhr.responseText) : {};
            const message = parsed?.detail || parsed?.message || "Upload failed";
            throw new Error(message);
          }

          setUploading(false);
          setUploadProgress(100);
          if (fileInputRef.current) fileInputRef.current.value = "";
          await loadDocuments();
          resolve();
        } catch (err) {
          setError(err.message || "Upload failed");
          reject(err);
        } finally {
          setUploading(false);
          setUploadProgress(0);
        }
      };

      xhr.onerror = () => {
        setUploading(false);
        setUploadProgress(0);
        const message = "Upload failed";
        setError(message);
        reject(new Error(message));
      };

      setUploading(true);
      setUploadProgress(0);
      setError("");
      xhr.send(formData);
    });
  }

  function handleUpload(event) {
    const file = event.target.files?.[0];
    uploadFile(file);
  }

  function handleDrop(event) {
    event.preventDefault();
    setDragActive(false);
    const file = event.dataTransfer.files?.[0];
    uploadFile(file);
  }

  const sourceItems = useMemo(() => {
    const groups = new Map();

    for (const doc of documents) {
      const key = doc.specialization;
      groups.set(key, (groups.get(key) || 0) + 1);
    }

    return [...groups.entries()].map(([title, count]) => ({
      title,
      type: `${count} file${count > 1 ? "s" : ""}`,
    }));
  }, [documents]);

  return (
    <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", xl: "280px minmax(0, 1fr) 320px" }, gap: 3 }}>
      <Paper
        sx={{
          border: 1,
          borderColor: "divider",
          borderRadius: 3,
          p: 2,
          bgcolor: "background.paper",
          minHeight: 620,
        }}
      >
        <Stack spacing={2}>
          <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <Typography variant="h6" sx={{ fontWeight: 700 }}>
              Sources
            </Typography>
            <Chip label={documents.length} size="small" sx={{ bgcolor: "primary.main", color: "#fff" }} />
          </Box>

          <List disablePadding sx={{ display: "flex", flexDirection: "column", gap: 1 }}>
            {sourceItems.length === 0 ? (
              <Typography variant="body2" color="text.secondary" sx={{ px: 1.5 }}>
                No sources yet
              </Typography>
            ) : (
              sourceItems.map((item) => (
                <ListItem key={item.title} disablePadding>
                  <ListItemButton
                    selected={item.title === sourceItems[0]?.title}
                    sx={{
                      borderRadius: 2,
                      px: 1.5,
                      py: 1,
                      "&.Mui-selected": {
                        bgcolor: "rgba(37, 99, 235, 0.08)",
                        color: "primary.main",
                      },
                    }}
                  >
                    <Box sx={{ mr: 1.5, display: "grid", placeItems: "center", width: 32, height: 32, borderRadius: 1.5, bgcolor: "rgba(37,99,235,0.1)" }}>
                      <FolderOutlined fontSize="small" />
                    </Box>
                    <ListItemText
                      primary={item.title}
                      secondary={item.type}
                      primaryTypographyProps={{ fontSize: 14, fontWeight: 600 }}
                      secondaryTypographyProps={{ fontSize: 12, color: "text.secondary" }}
                    />
                  </ListItemButton>
                </ListItem>
              ))
            )}
          </List>

          <Divider />

          <Stack spacing={1.5}>
            <Typography variant="caption" sx={{ fontWeight: 700, color: "text.secondary", letterSpacing: 0.5 }}>
              Recent activity
            </Typography>

            {documents.slice(0, 3).length === 0 ? (
              <Typography variant="body2" color="text.secondary">
                No recent activity yet.
              </Typography>
            ) : (
              documents.slice(0, 3).map((doc) => (
                <Box key={doc.id} sx={{ p: 1.5, borderRadius: 2, bgcolor: "rgba(15, 23, 42, 0.03)" }}>
                  <Typography sx={{ fontWeight: 600, mb: 0.3 }}>{doc.title}</Typography>
                  <Typography variant="caption" color="text.secondary">{doc.specialization}</Typography>
                </Box>
              ))
            )}
          </Stack>
        </Stack>
      </Paper>

      <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
        <Box sx={{ display: "flex", justifyContent: "space-between", gap: 2, alignItems: "center", flexWrap: "wrap" }}>
          <Box>
            <Typography variant="h4" sx={{ fontWeight: 700, mb: 0.5 }}>
              Documents
            </Typography>
            <Typography color="text.secondary">
              Manage curriculum resources, files, and learning materials.
            </Typography>
          </Box>

          <Stack direction="row" spacing={1.5} alignItems="center">
            <Button variant="secondary" startIcon={<FilterAltOutlined />}>
              Filters
            </Button>
          </Stack>
        </Box>

        <Box
          component="label"
          onClick={() => fileInputRef.current?.click()}
          onDragOver={(event) => {
            event.preventDefault();
            setDragActive(true);
          }}
          onDragLeave={() => setDragActive(false)}
          onDrop={handleDrop}
          sx={{
            border: "2px dashed",
            borderColor: dragActive ? "primary.main" : "divider",
            borderRadius: 3,
            p: 3,
            textAlign: "center",
            background: dragActive ? "rgba(37, 99, 235, 0.06)" : "rgba(15, 23, 42, 0.02)",
            cursor: "pointer",
            transition: "all 0.2s ease",
            mb: 2,
          }}
        >
          <input ref={fileInputRef} type="file" hidden onChange={handleUpload} />
          <Stack spacing={1.5} alignItems="center">
            <Box sx={{ width: 58, height: 58, borderRadius: 2, display: "grid", placeItems: "center", background: "rgba(37, 99, 235, 0.08)", color: "primary.main" }}>
              <CloudUploadOutlined sx={{ fontSize: 28 }} />
            </Box>
            <Box>
              <Typography variant="h6" sx={{ fontWeight: 700 }}>
                {dragActive ? "Drop file here" : "Drag & drop documents"}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                or click to browse from your device
              </Typography>
            </Box>
            {uploading && (
              <Box sx={{ width: "100%", maxWidth: 420 }}>
                <LinearProgress variant="determinate" value={uploadProgress} sx={{ height: 8, borderRadius: 999 }} />
                <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: "block" }}>
                  Uploading {uploadProgress}%
                </Typography>
              </Box>
            )}
          </Stack>
        </Box>

        {error && (
          <Box sx={{ mb: 2, p: 1.5, borderRadius: 2, bgcolor: "rgba(239, 68, 68, 0.06)", color: "error.main", fontSize: 14 }}>
            {error}
          </Box>
        )}

        <Card sx={{ border: 1, borderColor: "divider", borderRadius: 3, p: 2 }}>
          <Stack direction={{ xs: "column", md: "row" }} spacing={2} alignItems={{ xs: "stretch", md: "center" }} justifyContent="space-between">
            <Box sx={{ display: "flex", alignItems: "center", gap: 1, bgcolor: "rgba(15,23,42,0.03)", borderRadius: 2, px: 1.25, py: 0.75, minWidth: { xs: "100%", md: 360 } }}>
              <SearchOutlined color="action" />
              <Typography color="text.secondary">Search documents or authors…</Typography>
            </Box>

            <Stack direction="row" spacing={1}>
              <Chip label="All statuses" color="primary" variant="filled" />
              <Chip label="PDF" variant="outlined" />
              <Chip label="DOCX" variant="outlined" />
            </Stack>
          </Stack>
        </Card>

        <Card sx={{ border: 1, borderColor: "divider", borderRadius: 3, overflow: "hidden" }}>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700 }}>Title</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Specialization</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Status</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={4}>
                      <Typography color="text.secondary">Loading documents…</Typography>
                    </TableCell>
                  </TableRow>
                ) : error ? (
                  <TableRow>
                    <TableCell colSpan={4}>
                      <Typography color="error.main">{error}</Typography>
                    </TableCell>
                  </TableRow>
                ) : documents.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4}>
                      <Typography color="text.secondary">No documents found for this tenant.</Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  documents.map((doc) => (
                    <TableRow key={doc.id} hover>
                      <TableCell>
                        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                          <Box
                            sx={{
                              width: 36,
                              height: 36,
                              borderRadius: 2,
                              background: "rgba(37, 99, 235, 0.10)",
                              display: "grid",
                              placeItems: "center",
                              color: "primary.main",
                            }}
                          >
                            {(() => {
                              const typeMeta = getFileTypeMeta(doc.fileName || doc.title);
                              const Icon = typeMeta.Icon;
                              return <Icon fontSize="small" sx={{ color: typeMeta.color }} />;
                            })()}
                          </Box>
                          <Typography sx={{ fontWeight: 600 }}>{doc.title}</Typography>
                        </Box>
                      </TableCell>
                      <TableCell>{doc.specialization}</TableCell>
                      <TableCell><DocStatusChip status={doc.status} /></TableCell>
                      <TableCell>
                        <Stack direction="row" spacing={0.5}>
                          <Button variant="secondary" size="small" startIcon={<OpenInNewOutlined />} onClick={() => openDocument(doc)}>
                            View
                          </Button>
                          <Button variant="secondary" size="small" startIcon={<DownloadOutlined />} onClick={() => downloadDocument(doc)}>
                            Download
                          </Button>
                        </Stack>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Card>
      </Box>

    </Box>
  );
}
