import {
  Box,
  Button,
  Chip,
  Divider,
  IconButton,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
import {
  ArrowForwardRounded,
  CheckCircleOutlined,
  DownloadOutlined,
  ErrorOutlineOutlined,
  FilterListOutlined,
  MoreHorizOutlined,
  PlayArrowOutlined,
  SearchOutlined,
  ShieldOutlined,
  TuneOutlined,
  VisibilityOutlined,
} from "@mui/icons-material";

const runs = [
  {
    id: "run_48f9e2b1",
    target: "Junior Data Analyst (3-agent)",
    status: "Running",
    startedAt: "10:28:14 AM",
    duration: "42s",
    tokens: "14, 820",
    estCost: "$0.044",
    statusColor: "#fbbf24",
    statusBg: "rgba(251, 191, 36, 0.14)",
  },
  {
    id: "run_19a3bc74",
    target: "Cloud Architecture Outline",
    status: "Done",
    startedAt: "Yesterday",
    duration: "1m 12s",
    tokens: "38, 198",
    estCost: "$0.114",
    statusColor: "#34d399",
    statusBg: "rgba(52, 211, 153, 0.14)",
  },
  {
    id: "run_88e4d1d2",
    target: "Database Normalization Test",
    status: "Failed",
    startedAt: "Oct 17 09:30",
    duration: "18s",
    tokens: "4, 120",
    estCost: "$0.012",
    statusColor: "#f87171",
    statusBg: "rgba(248, 113, 113, 0.14)",
  },
];

function StatusBadge({ label, color, bg }) {
  return (
    <Chip
      label={label}
      size="small"
      sx={{
        backgroundColor: bg,
        color,
        borderRadius: 999,
        fontWeight: 700,
        height: 28,
        px: 0.5,
      }}
    />
  );
}

export default function RunsPage() {
  return (
    <Box
      sx={{
        minHeight: "100%",
        borderRadius: 3,
        background: "linear-gradient(180deg, rgba(10, 18, 35, 0.96) 0%, rgba(10, 18, 35, 0.97) 100%)",
        border: "1px solid rgba(148, 163, 184, 0.25)",
        boxShadow: "0 24px 74px rgba(5, 14, 34, 0.32)",
        overflow: "hidden",
      }}
    >
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          px: 2.5,
          py: 1.6,
          borderBottom: "1px solid rgba(148, 163, 184, 0.16)",
          background: "rgba(15, 23, 42, 0.35)",
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <Button variant="contained" size="small" startIcon={<PlayArrowOutlined />} sx={{ bgcolor: "#0f172a", color: "#e2e8f0", border: "1px solid rgba(148,163,184,0.2)", px: 1.5, py: 0.8 }}>
            Generate
          </Button>
          <Button variant="outlined" size="small" sx={{ borderColor: "rgba(148,163,184,0.22)", color: "#e2e8f0", px: 1.5, py: 0.8 }}>
            Modify
          </Button>
          <Button variant="outlined" size="small" sx={{ borderColor: "rgba(148,163,184,0.22)", color: "#e2e8f0", px: 1.5, py: 0.8 }}>
            Preview
          </Button>
          <Button variant="outlined" size="small" sx={{ borderColor: "rgba(148,163,184,0.22)", color: "#e2e8f0", px: 1.5, py: 0.8 }}>
            More
          </Button>
        </Box>

        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <IconButton sx={{ color: "#e2e8f0", border: "1px solid rgba(148,163,184,0.18)", background: "rgba(15,23,42,0.4)" }}>
            <DownloadOutlined fontSize="small" />
          </IconButton>
          <IconButton sx={{ color: "#e2e8f0", border: "1px solid rgba(148,163,184,0.18)", background: "rgba(15,23,42,0.4)" }}>
            <SearchOutlined fontSize="small" />
          </IconButton>
        </Box>
      </Box>

      <Box sx={{ px: 3, py: 2.4 }}>
        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 2 }}>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
            <Typography variant="h4" sx={{ fontWeight: 800, color: "#e2e8f0" }}>Runs &amp; Traces</Typography>
          </Box>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
            <Chip label="Trace Detail" size="small" sx={{ background: "rgba(148,163,184,0.12)", color: "#e2e8f0", borderRadius: 2, border: "1px solid rgba(148,163,184,0.2)" }} />
            <Chip label="All Runs Table" size="small" sx={{ background: "rgba(148,163,184,0.12)", color: "#e2e8f0", borderRadius: 2, border: "1px solid rgba(148,163,184,0.2)" }} />
          </Box>
        </Box>

        <Typography variant="body1" sx={{ color: "#cbd5e1", mb: 3, maxWidth: 700 }}>
          Comprehensive execution telemetry, correlation IDs, agent tool calls, and retrieved corpus chunks.
        </Typography>

        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            mb: 2,
            px: 0.75,
          }}
        >
          <Box sx={{ display: "flex", alignItems: "center", gap: 1.2, color: "#cbd5e1" }}>
            <ShieldOutlined sx={{ fontSize: 18 }} />
            <Typography sx={{ fontWeight: 700, color: "#e2e8f0" }}>Recent Runs Summary</Typography>
            <Chip label="3 active batches" size="small" sx={{ background: "rgba(59,130,246,0.12)", color: "#93c5fd", borderRadius: 999 }} />
          </Box>
          <Button variant="text" startIcon={<FilterListOutlined />} sx={{ color: "#e2e8f0", minWidth: 0 }}>
            Collapse
          </Button>
        </Box>

        <TableContainer
          component={Paper}
          sx={{
            background: "rgba(15, 23, 42, 0.72)",
            border: "1px solid rgba(148, 163, 184, 0.2)",
            borderRadius: 3,
            overflow: "hidden",
            boxShadow: "none",
          }}
        >
          <Table>
            <TableHead>
              <TableRow sx={{ background: "rgba(148, 163, 184, 0.04)" }}>
                <TableCell sx={{ color: "#cbd5e1", fontWeight: 700 }}>Run ID</TableCell>
                <TableCell sx={{ color: "#cbd5e1", fontWeight: 700 }}>Target Role / Workflow</TableCell>
                <TableCell sx={{ color: "#cbd5e1", fontWeight: 700 }}>Status</TableCell>
                <TableCell sx={{ color: "#cbd5e1", fontWeight: 700 }}>Started At</TableCell>
                <TableCell sx={{ color: "#cbd5e1", fontWeight: 700 }}>Duration</TableCell>
                <TableCell sx={{ color: "#cbd5e1", fontWeight: 700 }}>Total Tokens</TableCell>
                <TableCell sx={{ color: "#cbd5e1", fontWeight: 700 }}>Est. Cost</TableCell>
                <TableCell sx={{ color: "#cbd5e1", fontWeight: 700 }}>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {runs.map((run) => (
                <TableRow key={run.id} sx={{ "&:hover": { background: "rgba(148,163,184,0.04)" } }}>
                  <TableCell sx={{ color: "#e2e8f0", fontWeight: 600 }}>
                    <Box sx={{ display: "inline-flex", alignItems: "center", gap: 1 }}>
                      <Box sx={{ width: 10, height: 10, borderRadius: "50%", background: run.status === "Running" ? "#fbbf24" : run.status === "Done" ? "#34d399" : "#f87171" }} />
                      {run.id}
                    </Box>
                  </TableCell>
                  <TableCell sx={{ color: "#e2e8f0" }}>{run.target}</TableCell>
                  <TableCell>
                    <StatusBadge label={run.status} color={run.statusColor} bg={run.statusBg} />
                  </TableCell>
                  <TableCell sx={{ color: "#cbd5e1" }}>{run.startedAt}</TableCell>
                  <TableCell sx={{ color: "#cbd5e1" }}>{run.duration}</TableCell>
                  <TableCell sx={{ color: "#cbd5e1" }}>{run.tokens}</TableCell>
                  <TableCell sx={{ color: "#cbd5e1" }}>{run.estCost}</TableCell>
                  <TableCell>
                    <Button variant="text" size="small" sx={{ color: "#93c5fd", minWidth: 0 }} startIcon={<VisibilityOutlined />}>View Trace</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        <Box
          sx={{
            mt: 3,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            background: "rgba(15,23,42,0.72)",
            border: "1px solid rgba(148,163,184,0.2)",
            borderRadius: 3,
            px: 2,
            py: 1.5,
          }}
        >
          <Box sx={{ display: "flex", alignItems: "center", gap: 1.7 }}>
            <Typography variant="caption" sx={{ color: "#cbd5e1", fontWeight: 700, letterSpacing: 1.1 }}>Run ID</Typography>
            <Chip label="run_48f9e2b1" size="small" sx={{ borderRadius: 2, background: "rgba(148,163,184,0.08)", color: "#e2e8f0" }} />
            <Chip label="corr_99f3_iti_edu" size="small" sx={{ borderRadius: 2, background: "rgba(148,163,184,0.08)", color: "#e2e8f0" }} />
          </Box>

          <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
            <Typography variant="caption" sx={{ color: "#cbd5e1", fontWeight: 700 }}>TOTAL TOKENS</Typography>
            <Typography sx={{ color: "#f8fafc", fontWeight: 800 }}>14, 820</Typography>
            <Typography variant="caption" sx={{ color: "#cbd5e1", fontWeight: 700 }}>EST. COST</Typography>
            <Typography sx={{ color: "#f8fafc", fontWeight: 800 }}>$0.044 USD</Typography>
          </Box>
        </Box>

        <Box sx={{ mt: 3, background: "rgba(15,23,42,0.72)", border: "1px solid rgba(148,163,184,0.2)", borderRadius: 3, p: 2.25 }}>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, mb: 2 }}>
            <Chip label="Step 1" size="small" sx={{ background: "rgba(148,163,184,0.12)", color: "#e2e8f0", borderRadius: 2, fontWeight: 700 }} />
            <Typography sx={{ color: "#e2e8f0", fontWeight: 700 }}>Standards Mapper</Typography>
            <Typography sx={{ color: "#94a3b8" }}>• Tool:</Typography>
            <Typography sx={{ color: "#4ade80" }}>rag_vector_query(corpus=data_analysis_standards)</Typography>
            <Typography sx={{ color: "#94a3b8" }}>• Done (14.2s • 3,410 tokens)</Typography>
          </Box>

          <Box sx={{ border: "1px solid rgba(148,163,184,0.2)", borderRadius: 2, background: "rgba(148,163,184,0.04)", p: 1.5, mb: 2 }}>
            <Typography sx={{ color: "#cbd5e1", fontWeight: 700, mb: 1 }}>Retrieved Corpus Chunks (Top Similarity Matches):</Typography>
            <Stack direction="row" spacing={1.5} sx={{ flexWrap: "wrap", gap: 1.5 }}>
              {["WN-Lecture-03.pdf p. 14", "Python-Coding-Standards.docx p. 3"].map((item, idx) => (
                <Box key={item} sx={{ borderRadius: 2, border: "1px solid rgba(148,163,184,0.18)", background: "rgba(15,23,42,0.5)", px: 1.5, py: 1, display: "flex", alignItems: "center", gap: 1, minWidth: 220 }}>
                  <Box sx={{ width: 10, height: 10, borderRadius: "50%", background: idx === 0 ? "#60a5fa" : "#a78bfa" }} />
                  <Typography sx={{ color: "#e2e8f0", fontWeight: 600 }}>{item}</Typography>
                </Box>
              ))}
            </Stack>
          </Box>

          <Box sx={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 2 }}>
            <Box sx={{ background: "rgba(148,163,184,0.04)", border: "1px solid rgba(148,163,184,0.18)", borderRadius: 2, p: 1.5 }}>
              <Typography variant="caption" sx={{ color: "#cbd5e1", textTransform: "uppercase", fontWeight: 700 }}>Step input payload</Typography>
              <Typography sx={{ color: "#e2e8f0", mt: 1, whiteSpace: "pre-wrap" }}>{`{"role": "Junior Data Analyst", "competency_taxonomy": "[\"Pandas index manipulation\", \"Window SQL queries\"]"}`}</Typography>
            </Box>
            <Box sx={{ background: "rgba(148,163,184,0.04)", border: "1px solid rgba(148,163,184,0.18)", borderRadius: 2, p: 1.5 }}>
              <Typography variant="caption" sx={{ color: "#cbd5e1", textTransform: "uppercase", fontWeight: 700 }}>Step output payload</Typography>
              <Typography sx={{ color: "#e2e8f0", mt: 1, whiteSpace: "pre-wrap" }}>{`{\n  "gaps": [\n    "Pandas index manipulation\",\n    "Window SQL queries\"\n  ]\n}`}</Typography>
            </Box>
          </Box>
        </Box>

        <Box sx={{ mt: 3, background: "rgba(15,23,42,0.72)", border: "1px solid rgba(148,163,184,0.2)", borderRadius: 3, p: 2.25 }}>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, mb: 2 }}>
            <Chip label="Step 2" size="small" sx={{ background: "rgba(148,163,184,0.12)", color: "#e2e8f0", borderRadius: 2, fontWeight: 700 }} />
            <Typography sx={{ color: "#e2e8f0", fontWeight: 700 }}>Curriculum Designer</Typography>
            <Typography sx={{ color: "#94a3b8" }}>• Tool:</Typography>
            <Typography sx={{ color: "#4ade80" }}>module_structure_builder(units=4)</Typography>
            <Typography sx={{ color: "#94a3b8" }}>• Done (18.6s • 6,190 tokens)</Typography>
          </Box>

          <Box sx={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 2 }}>
            <Box sx={{ background: "rgba(148,163,184,0.04)", border: "1px solid rgba(148,163,184,0.18)", borderRadius: 2, p: 1.5 }}>
              <Typography variant="caption" sx={{ color: "#cbd5e1", textTransform: "uppercase", fontWeight: 700 }}>Step input payload</Typography>
              <Typography sx={{ color: "#e2e8f0", mt: 1, whiteSpace: "pre-wrap" }}>{`{"module": "Intro to data analysis", "units": 4}`}</Typography>
            </Box>
            <Box sx={{ background: "rgba(148,163,184,0.04)", border: "1px solid rgba(148,163,184,0.18)", borderRadius: 2, p: 1.5 }}>
              <Typography variant="caption" sx={{ color: "#cbd5e1", textTransform: "uppercase", fontWeight: 700 }}>Step output payload</Typography>
              <Typography sx={{ color: "#e2e8f0", mt: 1, whiteSpace: "pre-wrap" }}>{`{\n  "modules": [{\n    "id": 1,\n    "name": "Indexes and transactions\"\n  }]\n}`}</Typography>
            </Box>
          </Box>
        </Box>

        <Box
          sx={{
            mt: 3,
            p: 2.2,
            borderRadius: 3,
            background: "linear-gradient(135deg, rgba(148,163,184,0.14), rgba(15,23,42,0.8))",
            border: "1px solid rgba(148,163,184,0.18)",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 2,
          }}
        >
          <Box>
            <Typography sx={{ color: "#e2e8f0", fontWeight: 800, fontSize: 20 }}>What would you like to create or change?</Typography>
          </Box>

          <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
            <Button variant="outlined" size="small" sx={{ borderRadius: 2, borderColor: "rgba(148,163,184,0.18)", color: "#e2e8f0" }} startIcon={<ArrowForwardRounded />}>
              Balanced
            </Button>
            <Button variant="contained" size="small" sx={{ borderRadius: 2, background: "rgba(15,23,42,0.65)", color: "#e2e8f0", border: "1px solid rgba(148,163,184,0.18)" }}>
              92%
            </Button>
          </Box>
        </Box>
      </Box>
    </Box>
  );
}
