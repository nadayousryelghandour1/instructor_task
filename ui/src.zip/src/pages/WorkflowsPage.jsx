import { useEffect, useMemo, useState } from "react";
import {
  Box,
  Card,
  Chip,
  Divider,
  LinearProgress,
  List,
  ListItem,
  ListItemButton,
  ListItemText,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
import {
  Add,
  CheckCircleOutlined,
  CloudUploadOutlined,
  DescriptionOutlined,
  DownloadOutlined,
  InsertDriveFileOutlined,
  OpenInNewOutlined,
  PictureAsPdfOutlined,
  PlayArrowOutlined,
  SearchOutlined,
  ShieldOutlined,
  TableChartOutlined,
  TextSnippetOutlined,
} from "@mui/icons-material";
import Button from "../components/Button";
import { api } from "../api/client";

const API_BASE_URL = import.meta.env.VITE_API_URL ?? "http://localhost:8000";

function normalizeStatus(status) {
  const lower = String(status || "pending").toLowerCase();
  if (lower.includes("failed")) return "Failed";
  if (lower.includes("no_extractable")) return "No text extracted";
  if (lower.includes("processed") || lower.includes("process")) return "Processed";
  if (lower.includes("upload") || lower.includes("queued") || lower.includes("pending")) return "Processing...";
  return "Processing...";
}

function normalizeDocument(raw) {
  const title = raw.title || raw.filename || "Untitled document";
  return {
    id: raw.id || raw.document_id || title,
    title,
    fileName: title,
    specialization: raw.specialization || "General",
    status: normalizeStatus(raw.status),
  };
}

function getFileTypeMeta(fileName = "") {
  const extension = String(fileName.split(".").pop() || "").toLowerCase();
  const map = {
    pdf: { Icon: PictureAsPdfOutlined, color: "#f87171" },
    doc: { Icon: DescriptionOutlined, color: "#60a5fa" },
    docx: { Icon: DescriptionOutlined, color: "#60a5fa" },
    ppt: { Icon: TableChartOutlined, color: "#fbbf24" },
    pptx: { Icon: TableChartOutlined, color: "#fbbf24" },
    xls: { Icon: TableChartOutlined, color: "#34d399" },
    xlsx: { Icon: TableChartOutlined, color: "#34d399" },
    csv: { Icon: TextSnippetOutlined, color: "#22d3ee" },
    txt: { Icon: TextSnippetOutlined, color: "#a78bfa" },
    md: { Icon: TextSnippetOutlined, color: "#a78bfa" },
  };
  return map[extension] || { Icon: InsertDriveFileOutlined, color: "#94a3b8" };
}

function DocStatusChip({ status }) {
  const palette = {
    Processed: { color: "#34d399", bg: "rgba(52, 211, 153, 0.12)" },
    "Processing...": { color: "#fbbf24", bg: "rgba(251, 191, 36, 0.12)" },
    Failed: { color: "#f87171", bg: "rgba(248, 113, 113, 0.12)" },
    "No text extracted": { color: "#cbd5e1", bg: "rgba(148, 163, 184, 0.12)" },
  };
  const tone = palette[status] || { color: "#cbd5e1", bg: "rgba(148,163,184,0.08)" };

  return (
    <Chip
      label={status}
      size="small"
      sx={{
        borderRadius: 999,
        fontWeight: 700,
        backgroundColor: tone.bg,
        color: tone.color,
      }}
    />
  );
}

export default function WorkflowsPage() {
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [workflowLoading, setWorkflowLoading] = useState(false);
  const [workflowMessage, setWorkflowMessage] = useState("");
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  async function loadDocuments() {
    try {
      setLoading(true);
      setError("");
      const data = await api("/tenantdocs");
      setDocuments((Array.isArray(data) ? data : []).map(normalizeDocument));
    } catch (err) {
      setError(err.message || "Unable to load documents");
      setDocuments([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadDocuments();
  }, []);

  useEffect(() => {
    const hasActiveProcessing = documents.some((doc) => {
      const status = String(doc.status || "").toLowerCase();
      return status.includes("processing") || status.includes("upload") || status.includes("pending") || status.includes("queued");
    });

    if (!hasActiveProcessing) return undefined;
    const timer = setInterval(() => loadDocuments(), 4000);
    return () => clearInterval(timer);
  }, [documents]);

  async function uploadFile(file) {
    if (!file) return;
    const formData = new FormData();
    formData.append("file", file);

    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      const token = localStorage.getItem("access_token");
      xhr.open("POST", `${API_BASE_URL}/upload`);
      if (token) xhr.setRequestHeader("Authorization", `Bearer ${token}`);

      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable) setUploadProgress(Math.round((event.loaded / event.total) * 100));
      };

      xhr.onload = async () => {
        try {
          if (xhr.status >= 400) {
            const parsed = xhr.responseText ? JSON.parse(xhr.responseText) : {};
            throw new Error(parsed?.detail || parsed?.message || "Upload failed");
          }
          setUploading(false);
          setUploadProgress(100);
          await loadDocuments();
          resolve();
        } catch (err) {
          setError(err.message || "Upload failed");
          reject(err);
        } finally {
          setUploading(false);
          setUploadProgress(0);
        }
      };

      xhr.onerror = () => {
        setUploading(false);
        setUploadProgress(0);
        setError("Upload failed");
        reject(new Error("Upload failed"));
      };

      setUploading(true);
      setUploadProgress(0);
      setError("");
      xhr.send(formData);
    });
  }

  async function handleCreateWorkflow() {
    if (!documents.length) {
      setError("Upload at least one document before creating a workflow.");
      return;
    }

    try {
      setWorkflowLoading(true);
      setWorkflowMessage("");
      const result = await api("/workflow/runs", {
        method: "POST",
        body: {
          learning_goal: "Create assessment materials and mapping from the uploaded curriculum documents.",
        },
      });
      setWorkflowMessage(`Workflow started successfully. Run ID: ${result?.run_id || result?.id || "created"}`);
      await loadDocuments();
    } catch (err) {
      setError(err.message || "Unable to start workflow");
    } finally {
      setWorkflowLoading(false);
    }
  }

  const processedCount = documents.filter((doc) => doc.status === "Processed").length;
  const activeCount = documents.filter((doc) => doc.status === "Processing...").length;

  const workflowSteps = useMemo(() => [
    { label: "Ingest source files", active: documents.length > 0 },
    { label: "Chunk and index content", active: documents.length > 0 },
    { label: "Map standards", active: processedCount > 0 || activeCount > 0 },
    { label: "Review material", active: processedCount > 0 },
  ], [documents.length, processedCount, activeCount]);

  const workflowStatus = processedCount > 0 ? "Healthy" : activeCount > 0 ? "Processing..." : "Waiting";
  const workflowStatusColor = processedCount > 0 ? "#34d399" : activeCount > 0 ? "#fbbf24" : "#cbd5e1";

  function buildDocumentUrl(doc) {
    return `${API_BASE_URL}/uploads/${doc.id}_${encodeURIComponent(doc.fileName || doc.title)}`;
  }

  function openDocument(doc) {
    window.open(buildDocumentUrl(doc), "_blank", "noopener,noreferrer");
  }

  function downloadDocument(doc) {
    const url = buildDocumentUrl(doc);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = doc.fileName || doc.title;
    anchor.target = "_blank";
    anchor.rel = "noopener noreferrer";
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
  }

  return (
    <Box sx={{ minHeight: "100%", background: "#f8f9fb", p: { xs: 2, lg: 4 } }}>
      <Box
        sx={{
          maxWidth: 1380,
          mx: "auto",
          display: "grid",
          gridTemplateColumns: { xs: "1fr", xl: "360px minmax(0, 1fr)" },
          gap: 3.5,
          alignItems: "stretch",
        }}
      >
        <Paper
          elevation={0}
          sx={{
            borderRadius: 3,
            p: 2.5,
            background: "#ffffff",
            border: "1px solid rgba(15, 23, 42, 0.08)",
            boxShadow: "0 8px 24px rgba(15, 23, 42, 0.04)",
          }}
        >
          <Stack spacing={2.5}>
            <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", pb: 1.5, borderBottom: "1px solid rgba(15,23,42,0.08)" }}>
              <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                <Box sx={{ width: 28, height: 28, borderRadius: 1.5, background: "#edf3ff", display: "grid", placeItems: "center" }}>
                  <PlayArrowOutlined sx={{ fontSize: 18, color: "#2563eb" }} />
                </Box>
                <Typography variant="h6" sx={{ fontWeight: 700, color: "#0f172a" }}>New Curriculum Run</Typography>
              </Box>
              <Chip label="Pipeline v2.4" size="small" sx={{ background: "#eef4ff", color: "#2563eb", borderRadius: 999, fontWeight: 700 }} />
            </Box>

            <Stack spacing={2}>
              <Box>
                <Typography variant="body2" sx={{ fontWeight: 600, color: "#0f172a", mb: 1 }}>Target Role</Typography>
                <Box sx={{ background: "#f8fafc", border: "1px solid rgba(148,163,184,0.32)", borderRadius: 2, px: 1.5, py: 1.1, color: "#0f172a", fontWeight: 500 }}>
                  Junior Data Analyst
                </Box>
              </Box>

              <Box>
                <Typography variant="body2" sx={{ fontWeight: 600, color: "#0f172a", mb: 1 }}>Domain / Subject Track</Typography>
                <Box sx={{ background: "#f8fafc", border: "1px solid rgba(148,163,184,0.32)", borderRadius: 2, px: 1.5, py: 1.1, color: "#0f172a", fontWeight: 500 }}>
                  Data Analytics &amp; Engineering
                </Box>
              </Box>

              <Box>
                <Typography variant="body2" sx={{ fontWeight: 600, color: "#0f172a", mb: 1 }}>Number of Assessment Items</Typography>
                <Box sx={{ background: "#f8fafc", border: "1px solid rgba(148,163,184,0.32)", borderRadius: 2, px: 1.5, py: 1.1, color: "#0f172a", fontWeight: 500 }}>
                  15 items (5 Easy, 6 Medium, 4 Hard)
                </Box>
              </Box>

              <Box sx={{ background: "#f8fafc", border: "1px solid rgba(148,163,184,0.2)", borderRadius: 2, p: 1.5 }}>
                <Typography variant="body2" sx={{ fontWeight: 700, color: "#0f172a", mb: 1.2 }}>Source Corpus Scope</Typography>
                <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                  {['WN-Lecture-03', 'SQL-Advanced', 'Python-Standards'].map((tag) => (
                    <Chip key={tag} label={tag} size="small" sx={{ background: "#ffffff", border: "1px solid rgba(148,163,184,0.2)", color: "#475569", borderRadius: 999 }} />
                  ))}
                </Stack>
              </Box>
            </Stack>

            <Button variant="primary" onClick={handleCreateWorkflow} loading={workflowLoading} loadingText="Run in progress..." sx={{ mt: 1 }}>
              Run workflow
            </Button>
          </Stack>
        </Paper>

        <Paper
          elevation={0}
          sx={{
            borderRadius: 3,
            p: 3,
            background: "#ffffff",
            border: "1px solid rgba(15, 23, 42, 0.08)",
            boxShadow: "0 10px 30px rgba(15, 23, 42, 0.04)",
          }}
        >
          <Stack spacing={3}>
            <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 2, pb: 1.5, borderBottom: "1px solid rgba(15,23,42,0.08)" }}>
              <Box>
                <Typography variant="h3" sx={{ fontWeight: 800, color: "#0f172a", lineHeight: 1.15 }}>Workflows</Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>Run the 3-agent pipeline to generate competency maps and assessment items.</Typography>
              </Box>
              <Chip
                label={documents.length > 0 ? (activeCount > 0 ? "Running" : "Live") : "Idle"}
                size="small"
                sx={{
                  background: documents.length > 0 ? (activeCount > 0 ? "#eaf6ff" : "#eafaf1") : "#f1f5f9",
                  color: documents.length > 0 ? (activeCount > 0 ? "#0969da" : "#16a34a") : "#64748b",
                  borderRadius: 999,
                  fontWeight: 700,
                }}
              />
            </Box>

            <Paper sx={{ borderRadius: 2.5, border: "1px solid rgba(15,23,42,0.08)", background: "#f8fafc", p: 2 }}>
              <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 1.5 }}>
                <Typography variant="body2" color="text.secondary">Active run ID</Typography>
                <Typography variant="body2" sx={{ fontWeight: 700, color: "#0f172a" }}>
                  #{documents.length > 0 ? String(documents[0].id).slice(0, 6).toUpperCase() : "N/A"}
                </Typography>
              </Box>
              <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 1.5, mt: 1.5 }}>
                <Typography variant="body2" color="text.secondary">Status</Typography>
                <Chip label={workflowStatus} size="small" sx={{ background: workflowStatusColor + "22", color: workflowStatusColor, borderRadius: 999, fontWeight: 700 }} />
              </Box>
            </Paper>

            <Paper sx={{ borderRadius: 2.5, border: "1px solid rgba(15,23,42,0.08)", background: "#ffffff", p: 2.5 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 800, color: "#0f172a", mb: 2 }}>Workflow steps</Typography>
              <Stack spacing={1.8}>
                {workflowSteps.map((step, index) => (
                  <Box key={step.label} sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                    <Box
                      sx={{
                        width: 26,
                        height: 26,
                        borderRadius: "50%",
                        display: "grid",
                        placeItems: "center",
                        fontWeight: 800,
                        fontSize: 12,
                        background: step.active ? "#2563eb" : "#e2e8f0",
                        color: step.active ? "#fff" : "#475569",
                      }}
                    >
                      {step.active ? "✓" : index + 1}
                    </Box>
                    <Typography sx={{ color: step.active ? "#0f172a" : "#64748b", fontWeight: step.active ? 700 : 500 }}>{step.label}</Typography>
                  </Box>
                ))}
              </Stack>
            </Paper>

            {error && (
              <Box sx={{ p: 1.5, borderRadius: 2, background: "rgba(239,68,68,0.08)", color: "#b91c1c", border: "1px solid rgba(239, 68, 68, 0.12)" }}>{error}</Box>
            )}

            {workflowMessage && (
              <Box sx={{ p: 1.5, borderRadius: 2, background: "rgba(59,130,246,0.08)", color: "#1d4ed8", border: "1px solid rgba(59,130,246,0.12)" }}>{workflowMessage}</Box>
            )}
          </Stack>
        </Paper>

      </Box>
    </Box>
  );
}
